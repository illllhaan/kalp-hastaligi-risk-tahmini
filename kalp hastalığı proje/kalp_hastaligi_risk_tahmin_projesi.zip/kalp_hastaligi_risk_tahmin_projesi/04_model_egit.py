import json
from datetime import datetime

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from kalp_utils import (
    CLEAN_DATA_PATH,
    FEATURE_DESCRIPTIONS,
    FEATURES,
    META_PATH,
    MODEL_DIR,
    MODEL_PATH,
    REPORT_DIR,
    load_data,
    validate_columns,
)

MODEL_DIR.mkdir(exist_ok=True)
REPORT_DIR.mkdir(exist_ok=True)

# 1) Veriyi hazırla
if CLEAN_DATA_PATH.exists():
    df = pd.read_csv(CLEAN_DATA_PATH)
    duplicate_count = 0
else:
    df, duplicate_count = load_data(drop_duplicates=True)
    df.to_csv(CLEAN_DATA_PATH, index=False)

validate_columns(df)

X = df[FEATURES]
y = df["target"]

# 2) Eğitim-test ayrımı
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y,
)

# 3) Karşılaştırılacak modeller
models = {
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("model", LogisticRegression(max_iter=1000, random_state=42)),
    ]),
    "Random Forest": RandomForestClassifier(
        n_estimators=300,
        random_state=42,
        class_weight="balanced",
    ),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
    "SVM": Pipeline([
        ("scaler", StandardScaler()),
        ("model", SVC(probability=True, random_state=42)),
    ]),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
model_results = []
trained_models = {}

for name, model in models.items():
    cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="accuracy")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    result = {
        "model": name,
        "cv_accuracy_mean": float(cv_scores.mean()),
        "cv_accuracy_std": float(cv_scores.std()),
        "test_accuracy": float(accuracy_score(y_test, y_pred)),
        "test_precision": float(precision_score(y_test, y_pred)),
        "test_recall": float(recall_score(y_test, y_pred)),
        "test_f1": float(f1_score(y_test, y_pred)),
        "test_roc_auc": float(roc_auc_score(y_test, y_proba)),
    }
    model_results.append(result)
    trained_models[name] = model

# CV doğruluğu en yüksek modeli seçiyoruz.
best_result = max(model_results, key=lambda item: item["cv_accuracy_mean"])
best_model_name = best_result["model"]
best_model = trained_models[best_model_name]

# En iyi modeli test verisinde tekrar değerlendir.
y_pred = best_model.predict(X_test)
y_proba = best_model.predict_proba(X_test)[:, 1]
cm = confusion_matrix(y_test, y_pred)
report = classification_report(y_test, y_pred, target_names=["Risk yok", "Risk var"])

# 4) Modeli ve metadatasını kaydet
joblib.dump(best_model, MODEL_PATH)

metadata = {
    "project_name": "Kalp Hastalığı Risk Tahmin Sistemi",
    "created_at": datetime.now().isoformat(timespec="seconds"),
    "selected_model": best_model_name,
    "target": "target",
    "features": FEATURES,
    "feature_descriptions": FEATURE_DESCRIPTIONS,
    "row_count_after_cleaning": int(df.shape[0]),
    "column_count": int(df.shape[1]),
    "duplicate_count_removed_from_raw_data": int(duplicate_count),
    "results": model_results,
    "best_result": best_result,
    "confusion_matrix": cm.tolist(),
}
META_PATH.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

# 5) Rapor dosyası oluştur
report_text = f"""
KALP HASTALIĞI RİSK TAHMİN MODELİ RAPORU
==========================================

Temiz veri boyutu: {df.shape}
Hedef değişken: target
Seçilen model: {best_model_name}

Model karşılaştırma sonuçları:
{pd.DataFrame(model_results).to_string(index=False)}

Karışıklık matrisi:
{cm}

Detaylı sınıflandırma raporu:
{report}

Not:
Bu proje eğitim amaçlıdır. Çıktılar tıbbi teşhis yerine geçmez.
""".strip()

(REPORT_DIR / "model_raporu.txt").write_text(report_text, encoding="utf-8")

# 6) Grafikler oluştur
plt.figure(figsize=(6, 4))
plt.imshow(cm)
plt.title("Karışıklık Matrisi")
plt.xlabel("Tahmin")
plt.ylabel("Gerçek")
plt.xticks([0, 1], ["Risk yok", "Risk var"])
plt.yticks([0, 1], ["Risk yok", "Risk var"])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, cm[i, j], ha="center", va="center")
plt.tight_layout()
plt.savefig(REPORT_DIR / "karisiklik_matrisi.png", dpi=160)
plt.close()

results_df = pd.DataFrame(model_results).sort_values("cv_accuracy_mean", ascending=False)
plt.figure(figsize=(8, 4))
plt.bar(results_df["model"], results_df["cv_accuracy_mean"])
plt.title("Model Karşılaştırması - Ortalama CV Doğruluğu")
plt.ylabel("Doğruluk")
plt.xticks(rotation=25, ha="right")
plt.tight_layout()
plt.savefig(REPORT_DIR / "model_karsilastirma.png", dpi=160)
plt.close()

print("Model eğitimi tamamlandı.")
print("Seçilen model:", best_model_name)
print("Test doğruluğu:", round(best_result["test_accuracy"], 4))
print("F1 skoru:", round(best_result["test_f1"], 4))
print("ROC-AUC:", round(best_result["test_roc_auc"], 4))
print("Model kaydedildi:", MODEL_PATH)
print("Rapor kaydedildi:", REPORT_DIR / "model_raporu.txt")
