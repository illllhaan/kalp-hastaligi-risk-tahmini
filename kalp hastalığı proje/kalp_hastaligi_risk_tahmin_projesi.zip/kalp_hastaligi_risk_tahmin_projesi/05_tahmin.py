import json

import joblib

from kalp_utils import FEATURE_DESCRIPTIONS, FEATURES, META_PATH, MODEL_PATH, prepare_input


def ask_number(feature):
    while True:
        try:
            value = input(f"{feature} - {FEATURE_DESCRIPTIONS[feature]}: ").replace(",", ".")
            return float(value)
        except ValueError:
            print("Lütfen sayısal bir değer gir.")


if not MODEL_PATH.exists():
    raise FileNotFoundError("Model bulunamadı. Önce 04_model_egit.py dosyasını çalıştır.")

model = joblib.load(MODEL_PATH)
meta = json.loads(META_PATH.read_text(encoding="utf-8"))

print("Kalp Hastalığı Risk Tahmin Sistemi")
print("Bu çıktı tıbbi teşhis değildir; eğitim amaçlıdır.\n")
print("Aşağıdaki değerleri gir:")

user_data = {feature: ask_number(feature) for feature in FEATURES}
input_df = prepare_input(user_data)

prediction = int(model.predict(input_df)[0])
probability = float(model.predict_proba(input_df)[0][1])

print("\nSonuç")
print("------")
print("Kullanılan model:", meta["selected_model"])
print("Risk olasılığı:", f"%{probability * 100:.2f}")

if prediction == 1:
    print("Tahmin: Kalp hastalığı riski VAR / yüksek görünüyor.")
else:
    print("Tahmin: Kalp hastalığı riski YOK / düşük görünüyor.")

print("\nUyarı: Bu proje doktor tavsiyesi veya tıbbi teşhis yerine geçmez.")
