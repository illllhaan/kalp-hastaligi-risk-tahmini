@echo off
echo Gerekli kutuphaneler kuruluyor...
python -m pip install -r requirements.txt
pause
