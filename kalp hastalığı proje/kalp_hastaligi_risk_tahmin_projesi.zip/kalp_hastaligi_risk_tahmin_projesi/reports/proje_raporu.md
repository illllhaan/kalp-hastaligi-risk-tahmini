# Kalp Hastalığı Risk Tahmin Sistemi - Proje Raporu

## 1. Projenin Amacı

Bu projenin amacı, hastaya ait temel sağlık parametrelerini kullanarak kalp hastalığı riskini tahmin eden bir makine öğrenmesi sistemi geliştirmektir.

## 2. Problem Tanımı

Kalp hastalıkları erken fark edilmediğinde ciddi sonuçlara yol açabilir. Bu projede, veri setindeki `target` sütunu hedef değişken olarak kullanılmıştır:

- `0`: Kalp hastalığı yok / düşük risk
- `1`: Kalp hastalığı var / yüksek risk

## 3. Kullanılan Veri Seti

Veri setinde 14 sütun vardır. Bunlardan 13 tanesi modelin giriş değişkenidir; `target` sütunu ise tahmin edilmek istenen sonuçtur.

Giriş değişkenlerinden bazıları şunlardır:

- Yaş
- Cinsiyet
- Göğüs ağrısı tipi
- Dinlenme kan basıncı
- Kolesterol
- Maksimum kalp atış hızı
- Egzersize bağlı anjina
- ST depresyonu

## 4. Veri Ön İşleme

Veri üzerinde şu işlemler yapılmıştır:

1. CSV dosyası noktalı virgül ayırıcısıyla okunmuştur.
2. `oldpeak` sütunundaki Excel/WPS kaynaklı tarih dönüşümü hataları düzeltilmiştir.
3. Tüm sütunlar sayısal tipe çevrilmiştir.
4. Eksik veri kontrolü yapılmıştır.
5. Tekrar eden satırlar temizlenmiştir.

## 5. Kullanılan Modeller

Projede birden fazla sınıflandırma modeli denenmiştir:

- Logistic Regression
- Random Forest
- Gradient Boosting
- SVM

Modeller çapraz doğrulama yöntemiyle karşılaştırılmış ve en iyi sonucu veren model kaydedilmiştir.

## 6. Değerlendirme Metrikleri

Model başarısını ölçmek için şu metrikler kullanılmıştır:

- Accuracy
- Precision
- Recall
- F1-score
- ROC-AUC
- Confusion Matrix

## 7. Uygulama

Proje iki şekilde kullanılabilir:

1. Terminal üzerinden `05_tahmin.py` dosyasıyla
2. Streamlit web arayüzü üzerinden `app.py` dosyasıyla

## 8. Sınırlılıklar

Bu proje eğitim amaçlıdır. Kullanılan veri seti gerçek klinik karar verme sistemi yerine geçemez. Model sonucu doktor teşhisi değildir ve sağlık kararı almak için kullanılmamalıdır.

## 9. Sonuç

Bu proje, makine öğrenmesi kullanılarak kalp hastalığı risk tahmini yapılabileceğini gösteren temel ama tamamlanmış bir örnektir. Veri temizleme, model eğitimi, değerlendirme ve kullanıcı arayüzü adımlarını içermektedir.
