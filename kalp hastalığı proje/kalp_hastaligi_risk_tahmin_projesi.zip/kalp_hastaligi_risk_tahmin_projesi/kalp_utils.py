from pathlib import Path
import re
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"

RAW_DATA_PATH = DATA_DIR / "heart.csv"
CLEAN_DATA_PATH = DATA_DIR / "heart_temiz.csv"
MODEL_PATH = MODEL_DIR / "kalp_modeli.pkl"
META_PATH = MODEL_DIR / "model_bilgileri.json"

FEATURES = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal"
]

FEATURE_DESCRIPTIONS = {
    "age": "Yaş",
    "sex": "Cinsiyet: 0=Kadın, 1=Erkek",
    "cp": "Göğüs ağrısı tipi: 0-3 arası kodlanmış değer",
    "trestbps": "Dinlenme kan basıncı",
    "chol": "Kolesterol",
    "fbs": "Açlık kan şekeri > 120 mg/dl: 0=Hayır, 1=Evet",
    "restecg": "Dinlenme EKG sonucu: 0-2 arası kodlanmış değer",
    "thalach": "Ulaşılan maksimum kalp atış hızı",
    "exang": "Egzersize bağlı anjina: 0=Hayır, 1=Evet",
    "oldpeak": "Egzersize bağlı ST depresyonu",
    "slope": "ST segment eğimi: 0-2 arası kodlanmış değer",
    "ca": "Floroskopi ile görülen ana damar sayısı: 0-4",
    "thal": "Talasemi değeri: 0-3 arası kodlanmış değer",
}

MONTH_TO_DECIMAL = {
    "Oca": 1, "Ocak": 1,
    "Şu": 2, "Şub": 2, "Sub": 2, "Şubat": 2,
    "Mar": 3, "Mart": 3,
    "Nis": 4, "Nisan": 4,
    "May": 5, "Mayıs": 5, "Mayis": 5,
    "Haz": 6, "Haziran": 6,
    "Tem": 7, "Temmuz": 7,
    "Ağ": 8, "Ağu": 8, "Agu": 8, "Ağustos": 8, "Agustos": 8,
    "Eyl": 9, "Eylül": 9, "Eylul": 9,
    "Eki": 10, "Ekim": 10,
    "Kas": 11, "Kasım": 11, "Kasim": 11,
    "Ara": 12, "Aralık": 12, "Aralik": 12,
}


def fix_oldpeak(value):
    """Excel/WPS'in 3.1 gibi değerleri 3.Oca şeklinde tarihe çevirmesini düzeltir."""
    if pd.isna(value):
        return value

    text = str(value).strip().replace(",", ".")

    try:
        return float(text)
    except ValueError:
        pass

    match = re.match(r"^(\d+)\.([A-Za-zÇĞİÖŞÜçğıöşü]+)$", text)
    if match:
        integer_part = int(match.group(1))
        month_name = match.group(2)
        if month_name in MONTH_TO_DECIMAL:
            decimal_part = MONTH_TO_DECIMAL[month_name]
            return float(f"{integer_part}.{decimal_part}")

    raise ValueError(f"oldpeak değeri dönüştürülemedi: {value}")


def load_data(path=RAW_DATA_PATH, drop_duplicates=True):
    """CSV dosyasını okur, oldpeak hatalarını düzeltir ve sayısal tipe çevirir."""
    df = pd.read_csv(path, sep=";")
    df.columns = [col.strip() for col in df.columns]

    if "oldpeak" in df.columns:
        df["oldpeak"] = df["oldpeak"].apply(fix_oldpeak)

    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="raise")

    duplicate_count = int(df.duplicated().sum())
    if drop_duplicates:
        df = df.drop_duplicates().reset_index(drop=True)

    return df, duplicate_count


def validate_columns(df):
    required = set(FEATURES + ["target"])
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Eksik sütunlar: {sorted(missing)}")


def prepare_input(data_dict):
    """Tahmin için tek satırlık DataFrame oluşturur."""
    return pd.DataFrame([[data_dict[col] for col in FEATURES]], columns=FEATURES)
