import json

import joblib
import streamlit as st

from kalp_utils import FEATURE_DESCRIPTIONS, META_PATH, MODEL_PATH, prepare_input

st.set_page_config(page_title="Kalp Hastalığı Risk Tahmini", page_icon="❤️", layout="centered")

st.title("❤️ Kalp Hastalığı Risk Tahmin Sistemi")
st.write("Bu uygulama, verilen sağlık parametrelerine göre kalp hastalığı riskini tahmin eden eğitim amaçlı bir makine öğrenmesi projesidir.")
st.warning("Bu uygulama tıbbi teşhis veya doktor tavsiyesi değildir. Gerçek sağlık kararları için doktora başvurulmalıdır.")

if not MODEL_PATH.exists():
    st.error("Model dosyası bulunamadı. Önce terminalde `python 04_model_egit.py` komutunu çalıştır.")
    st.stop()

model = joblib.load(MODEL_PATH)
meta = json.loads(META_PATH.read_text(encoding="utf-8"))

st.sidebar.header("Model Bilgisi")
st.sidebar.write("Seçilen model:", meta.get("selected_model", "Bilinmiyor"))
st.sidebar.write("Temiz veri satır sayısı:", meta.get("row_count_after_cleaning", "-"))
st.sidebar.write("Test doğruluğu:", round(meta.get("best_result", {}).get("test_accuracy", 0), 4))

st.subheader("Hasta Bilgilerini Gir")

col1, col2 = st.columns(2)

with col1:
    age = st.number_input("Yaş", min_value=1, max_value=120, value=52)
    sex = st.selectbox("Cinsiyet", options=[0, 1], format_func=lambda x: "Kadın" if x == 0 else "Erkek")
    cp = st.selectbox("Göğüs ağrısı tipi (cp)", options=[0, 1, 2, 3])
    trestbps = st.number_input("Dinlenme kan basıncı", min_value=50, max_value=250, value=125)
    chol = st.number_input("Kolesterol", min_value=100, max_value=700, value=212)
    fbs = st.selectbox("Açlık kan şekeri > 120 mg/dl", options=[0, 1], format_func=lambda x: "Hayır" if x == 0 else "Evet")
    restecg = st.selectbox("Dinlenme EKG sonucu", options=[0, 1, 2])

with col2:
    thalach = st.number_input("Maksimum kalp atış hızı", min_value=50, max_value=250, value=168)
    exang = st.selectbox("Egzersize bağlı anjina", options=[0, 1], format_func=lambda x: "Hayır" if x == 0 else "Evet")
    oldpeak = st.number_input("Oldpeak / ST depresyonu", min_value=0.0, max_value=10.0, value=1.0, step=0.1)
    slope = st.selectbox("ST segment eğimi", options=[0, 1, 2])
    ca = st.selectbox("Ana damar sayısı", options=[0, 1, 2, 3, 4])
    thal = st.selectbox("Thal değeri", options=[0, 1, 2, 3])

user_data = {
    "age": age,
    "sex": sex,
    "cp": cp,
    "trestbps": trestbps,
    "chol": chol,
    "fbs": fbs,
    "restecg": restecg,
    "thalach": thalach,
    "exang": exang,
    "oldpeak": oldpeak,
    "slope": slope,
    "ca": ca,
    "thal": thal,
}

with st.expander("Sütun açıklamaları"):
    for key, value in FEATURE_DESCRIPTIONS.items():
        st.write(f"**{key}:** {value}")

if st.button("Risk Tahmini Yap"):
    input_df = prepare_input(user_data)
    prediction = int(model.predict(input_df)[0])
    probability = float(model.predict_proba(input_df)[0][1])

    st.subheader("Tahmin Sonucu")
    st.metric("Risk olasılığı", f"%{probability * 100:.2f}")

    if prediction == 1:
        st.error("Tahmin: Kalp hastalığı riski VAR / yüksek görünüyor.")
    else:
        st.success("Tahmin: Kalp hastalığı riski YOK / düşük görünüyor.")

    st.write("Girilen değerler:")
    st.dataframe(input_df)
