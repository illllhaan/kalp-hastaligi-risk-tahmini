@echo off
echo Model egitimi basliyor...
python 03_veri_temizle.py
python 04_model_egit.py
pause
