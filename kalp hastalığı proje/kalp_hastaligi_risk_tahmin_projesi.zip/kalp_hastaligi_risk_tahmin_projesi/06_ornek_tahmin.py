import json

import joblib

from kalp_utils import META_PATH, MODEL_PATH, prepare_input

# Örnek hasta verisi. Değerleri değiştirerek farklı senaryolar deneyebilirsin.
ornek_hasta = {
    "age": 52,
    "sex": 1,
    "cp": 0,
    "trestbps": 125,
    "chol": 212,
    "fbs": 0,
    "restecg": 1,
    "thalach": 168,
    "exang": 0,
    "oldpeak": 1.0,
    "slope": 2,
    "ca": 2,
    "thal": 3,
}

if not MODEL_PATH.exists():
    raise FileNotFoundError("Model bulunamadı. Önce 04_model_egit.py dosyasını çalıştır.")

model = joblib.load(MODEL_PATH)
meta = json.loads(META_PATH.read_text(encoding="utf-8"))

input_df = prepare_input(ornek_hasta)
prediction = int(model.predict(input_df)[0])
probability = float(model.predict_proba(input_df)[0][1])

print("Örnek hasta verisi:")
print(input_df)
print("\nModel:", meta["selected_model"])
print("Risk olasılığı:", f"%{probability * 100:.2f}")
print("Tahmin:", "Risk var" if prediction == 1 else "Risk yok")
