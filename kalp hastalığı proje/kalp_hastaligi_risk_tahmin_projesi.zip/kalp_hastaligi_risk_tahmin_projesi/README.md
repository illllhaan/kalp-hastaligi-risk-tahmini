# Kalp Hastalığı Risk Tahmin Sistemi

Bu proje, `heart.csv` veri setini kullanarak kalp hastalığı riskini tahmin eden bir makine öğrenmesi projesidir.

> Uyarı: Bu proje eğitim amaçlıdır. Tıbbi teşhis veya doktor tavsiyesi yerine geçmez.

## Proje İçeriği

- `data/heart.csv`: Ham veri seti
- `03_veri_temizle.py`: Veriyi temizler ve `heart_temiz.csv` oluşturur
- `04_model_egit.py`: Modelleri eğitir, karşılaştırır ve en iyi modeli kaydeder
- `05_tahmin.py`: Terminalden kullanıcı girdisiyle tahmin yapar
- `06_ornek_tahmin.py`: Hazır örnek veriyle tahmin yapar
- `app.py`: Streamlit arayüzlü web uygulaması
- `reports/model_raporu.txt`: Model başarı raporu
- `reports/karisiklik_matrisi.png`: Karışıklık matrisi grafiği
- `reports/model_karsilastirma.png`: Model karşılaştırma grafiği

## Kurulum

Terminali proje klasöründe aç ve şu komutu çalıştır:

```bash
python -m pip install -r requirements.txt
```

Windows'ta istersen `kurulum.bat` dosyasına çift tıklayabilirsin.

## Çalıştırma Sırası

### 1. Veriyi temizle

```bash
python 03_veri_temizle.py
```

### 2. Modeli eğit

```bash
python 04_model_egit.py
```

Bu komut şunları oluşturur:

- `models/kalp_modeli.pkl`
- `models/model_bilgileri.json`
- `reports/model_raporu.txt`
- `reports/karisiklik_matrisi.png`
- `reports/model_karsilastirma.png`

### 3. Terminalden tahmin yap

```bash
python 05_tahmin.py
```

### 4. Web arayüzünü aç

```bash
streamlit run app.py
```

Sonra tarayıcıda uygulama açılır.

## Veri Setindeki Sütunlar

| Sütun | Anlamı |
|---|---|
| age | Yaş |
| sex | Cinsiyet: 0=Kadın, 1=Erkek |
| cp | Göğüs ağrısı tipi |
| trestbps | Dinlenme kan basıncı |
| chol | Kolesterol |
| fbs | Açlık kan şekeri > 120 mg/dl |
| restecg | Dinlenme EKG sonucu |
| thalach | Maksimum kalp atış hızı |
| exang | Egzersize bağlı anjina |
| oldpeak | ST depresyonu |
| slope | ST segment eğimi |
| ca | Ana damar sayısı |
| thal | Talasemi değeri |
| target | 0=Risk yok, 1=Risk var |

## Notlar

Veri setinde `oldpeak` sütununda Excel/WPS kaynaklı bozulmalar vardı. Örneğin `3.1` değeri `3.Oca` gibi görünebiliyordu. Bu proje içinde bu sorun otomatik temizleniyor.

Ayrıca ham veri setinde çok sayıda tekrar eden satır vardı. Modelin gerçekçi değerlendirilmesi için tekrar eden satırlar temizlenmiştir.
