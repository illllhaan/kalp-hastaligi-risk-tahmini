@echo off
echo Streamlit uygulamasi aciliyor...
streamlit run app.py
pause
