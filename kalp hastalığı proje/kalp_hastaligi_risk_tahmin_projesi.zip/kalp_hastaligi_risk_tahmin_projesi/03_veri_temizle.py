from kalp_utils import load_data, validate_columns, CLEAN_DATA_PATH, DATA_DIR

DATA_DIR.mkdir(exist_ok=True)

df, duplicate_count = load_data(drop_duplicates=True)
validate_columns(df)

df.to_csv(CLEAN_DATA_PATH, index=False)

print("Veri temizleme tamamlandı.")
print("Ham veride silinen tekrar eden satır sayısı:", duplicate_count)
print("Temiz veri boyutu:", df.shape)
print("Temiz dosya kaydedildi:", CLEAN_DATA_PATH)
print("Eksik veri sayısı:")
print(df.isnull().sum())
