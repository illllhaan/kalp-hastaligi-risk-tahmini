from kalp_utils import load_data, validate_columns

# Temizlenmiş ve tekrarsız veri üzerinden temel analiz yapıyoruz.
df, duplicate_count = load_data(drop_duplicates=True)
validate_columns(df)

print("Ham veride tekrar eden satır sayısı:", duplicate_count)
print("Tekrarsız veri boyutu:", df.shape)

print("\nTarget değerleri:")
print(df["target"].value_counts())

print("\nYüzdelik dağılım:")
print((df["target"].value_counts(normalize=True) * 100).round(2))

print("\nSütunların açıklaması:")
print("target = 0: kalp hastalığı yok/düşük risk")
print("target = 1: kalp hastalığı var/yüksek risk")
