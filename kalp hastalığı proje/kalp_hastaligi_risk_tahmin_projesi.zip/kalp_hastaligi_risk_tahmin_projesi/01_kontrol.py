import pandas as pd
from kalp_utils import RAW_DATA_PATH

# Ham veriyi oku. Bu CSV noktalı virgül ile ayrıldığı için sep=";" kullanıyoruz.
df = pd.read_csv(RAW_DATA_PATH, sep=";")

print("İlk 5 satır:")
print(df.head())

print("\nSütun isimleri:")
print(df.columns)

print("\nVeri boyutu:")
print(df.shape)

print("\nEksik veri sayısı:")
print(df.isnull().sum())
